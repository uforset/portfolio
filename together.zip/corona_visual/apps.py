from django.apps import AppConfig


class CoronaVisualConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'corona_visual'
