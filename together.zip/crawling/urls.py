from django.urls import path
from . import views

app_name = 'crawling'
urlpatterns = [
    # path('', views.country_setting, name= 'crawling'),  #초기 세팅이므로 바로 주석처리
]
